-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 04, 2026 at 08:20 PM
-- Server version: 8.0.46-0ubuntu0.22.04.2
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enjaz_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'اسم العميل',
  `company_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'اسم الشركة',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'رقم الموبايل',
  `mobile_2` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'رقم موبايل إضافي',
  `activity` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'النشاط التجاري',
  `domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain_provider` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username_note` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'اسم المستخدم (للإشارة)',
  `email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=نشط, 0=موقوف',
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `company_name`, `mobile`, `mobile_2`, `activity`, `domain`, `domain_provider`, `username_note`, `email`, `address`, `notes`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'م / باسم', 'مكتب مشعل بادغيش', '966598012129', '966598012129', 'مكتب محاماة', '', 'GoDaddy', '', '', '', '', 1, 1, '2026-06-04 13:13:44', '2026-06-04 14:16:26'),
(2, 'م / مصعب نبيل', 'Kentro TFM', '201112957899', '', 'interior design', 'kentrotfm.com', 'Namecheap', 'kentrotfm', '', '', '', 1, 1, '2026-06-04 13:35:02', '2026-06-04 14:20:56'),
(3, 'م / محمد', 'servot', '201277795959', '201015308608', 'interior design', 'servot.co', 'GoDaddy', 'servot', '', '', '', 1, 1, '2026-06-04 13:45:56', '2026-06-04 14:15:58'),
(4, 'م / اشرف', 'nexforges', '201220003177', '', '', 'nexforges.com', 'GoDaddy', 'nexforges', '', '', '', 1, 1, '2026-06-04 14:17:11', '2026-06-04 14:17:11'),
(5, 'م / محمود', 'Flourish Landscaping', '201000008145', '', 'interior design', 'flourish-landscaping.com', 'Namecheap', 'flourish', '', '', '', 1, 1, '2026-06-04 14:19:02', '2026-06-04 14:19:02'),
(6, 'م / احمد سعيد', 'Smart Source', '201019826096', '', 'Electronics shop', 'smartsource-eg.com', 'GoDaddy', 'smartsource', '', '', '', 1, 1, '2026-06-04 14:23:20', '2026-06-04 14:38:22'),
(7, 'م / الطيب', 'Royal Smart', '201097488085', '', 'عمالة خارجية', 'royalsmart-rs.com', 'GoDaddy', 'royalsmart', '', '', '', 1, 1, '2026-06-04 14:37:23', '2026-06-04 14:39:36'),
(8, 'م / محمد مروان', 'Stars Services', '201012692176', '', 'خدمات النظافة', 'stars-smcs.com', 'GoDaddy', 'stars-smcs', '', '', '', 1, 1, '2026-06-04 14:44:51', '2026-06-04 14:44:51'),
(9, 'م / اسلام كامل', 'Namaa invest', '201099000850', '', 'Contracting', 'namaa-invests.com', 'GoDaddy', 'namaainvests', '', '', '', 1, 1, '2026-06-04 14:50:29', '2026-06-04 14:50:29'),
(10, 'م / احمد حماد', 'Micro Serial', '201023399311', '', 'online shop', 'microserial.com', 'GoDaddy', 'microserial', '', '', '', 1, 1, '2026-06-04 14:54:47', '2026-06-04 14:54:47'),
(11, 'م / رفعت كريم', 'Alauma Contracting', '201111130655', '', 'Contracting', 'alauma.com', 'GoDaddy', 'alauma', '', '', '', 1, 1, '2026-06-04 15:11:18', '2026-06-04 15:11:18'),
(12, 'د / محمد الجميعي', 'Onboarding 4u', '201003939499', '', 'قطاع الصيدليات', 'onboarding4u.com', 'GoDaddy', 'onboarding4u', '', '', '', 1, 1, '2026-06-04 15:14:13', '2026-06-04 15:14:13'),
(13, 'م / اسلام الشريف', 'Alsherif Group', '201119589121', '', 'Contracting', 'alsherifgroup.net', 'GoDaddy', 'alsherifgroup', '', '', '', 1, 1, '2026-06-04 15:18:47', '2026-06-04 15:18:47'),
(14, 'م / عاطف صلاح', 'التحدي تريد', '201000002267', '', 'استيراد وتصدير', 'eltahady-trade.com', 'GoDaddy', 'eltahadytrade', '', '', '', 1, 1, '2026-06-04 15:22:39', '2026-06-04 15:22:39'),
(15, 'م / عمار بهنس', 'Arab House Vent', '201143638874', '', 'Mep - HVAC', 'arabhousevent.com', 'GoDaddy', 'arabhousevent', '', '', '', 1, 1, '2026-06-04 15:24:54', '2026-06-04 15:24:54'),
(16, 'م / علي محمد', 'Blue Sea Metal', '201013982131', '', 'تشكيل المعان', 'bluesea-metal.com', 'GoDaddy', 'blueseametal', '', '', '', 1, 1, '2026-06-04 15:37:02', '2026-06-04 15:37:02'),
(17, 'م / بيشوي رأفت', 'innova Egypt', '201288333348', '', 'برمجيات', 'innova-egypt.com', 'GoDaddy', 'innova-egypt', '', '', '', 1, 1, '2026-06-04 15:42:10', '2026-06-04 15:42:10'),
(18, 'DR. Aya A Ahmed', 'Admissions Office', '201044929476', '', 'قطاع التعليم', 'admissions-office-eg.com', 'GoDaddy', 'admissions-office', '', '', '', 1, 1, '2026-06-04 15:44:49', '2026-06-04 15:44:49'),
(19, 'د / طه منصور', 'TM Medical', '201016225666', '', 'القطاع الطبي', 'tm-medical.net', 'GoDaddy', 'tm-medical', '', '', '', 1, 1, '2026-06-04 15:48:14', '2026-06-04 15:48:14'),
(20, 'م / بيتر فيكتور', 'AMD Consttructions', '201001479363', '', 'Contracting', 'amdconst.com', 'GoDaddy', 'amdconst', '', '', '', 1, 1, '2026-06-04 15:53:52', '2026-06-04 15:53:52'),
(21, 'م / محمد نصر', 'همة وطن', '201128478217', '', 'Contracting', 'hemmatwatn.com', 'GoDaddy', 'hemmatwatn', '', '', '', 1, 1, '2026-06-04 15:56:14', '2026-06-04 15:56:14'),
(22, 'م / مازن', 'مازن كو', '201055144517', '', 'القطاع المالي', 'mazenco.info', 'GoDaddy', 'mazenco', '', '', '', 1, 1, '2026-06-04 15:57:53', '2026-06-04 15:57:53'),
(23, 'م / اسلام البلتاجي', 'Gladious Scape', '201207575483', '', 'Landscaping', 'gladiousscape.com', '', 'gladiousscape', '', '', '', 1, 1, '2026-06-04 15:59:19', '2026-06-04 15:59:19'),
(24, 'م / احمد يوسف', 'Dimec', '201028071308', '', 'التوريدات', 'dimec-eg.com', 'GoDaddy', 'dimec-eg', '', '', '', 1, 1, '2026-06-04 16:01:46', '2026-06-04 16:01:46'),
(25, 'م / نانسي', 'Vera Agency', '201206671454', '', 'Agency', 'veraagency-eg.com', 'GoDaddy', 'veraagency', '', '', '', 1, 1, '2026-06-04 16:05:19', '2026-06-04 16:05:19'),
(26, 'د / عبد الرحمن', 'Advanced Tech', '201274432551', '', 'Tech', 'advancedtech-eg.com', 'GoDaddy', 'advancedtech', '', '', '', 1, 1, '2026-06-04 16:08:40', '2026-06-04 16:08:40'),
(27, 'م / محمود نور الدين', 'Valve Link', '201018067511', '', 'PLUMBING', 'valvelink.co', 'GoDaddy', 'valvelink', '', '', '', 1, 1, '2026-06-04 16:12:11', '2026-06-04 16:12:11'),
(28, 'م / عمرو محمد', 'Alex Air', '201226178167', '', 'HVAC', 'alexair-eg.com', 'GoDaddy', 'alexair', '', '', '', 1, 1, '2026-06-04 16:16:15', '2026-06-04 16:16:15'),
(29, 'م / رامي عبد اللطيف', 'First Air', '201067996402', '', 'Mep - HVAC', 'first-air-eg.com', 'GoDaddy', 'firstair', '', '', '', 1, 1, '2026-06-04 16:19:46', '2026-06-04 16:31:41'),
(30, 'م / صابر مكي', 'shariha', '966561036181', '', 'telecom', 'shariha.net', 'GoDaddy', 'shariha', '', '', '', 1, 1, '2026-06-04 16:34:00', '2026-06-04 16:34:00'),
(31, 'م / محمد', 'Metal Power', '201090416807', '', 'Contracting', 'metalpwr.com', 'GoDaddy', 'metalpwr', '', '', '', 1, 1, '2026-06-04 18:40:00', '2026-06-04 18:40:00'),
(32, 'م / احمد نجم', 'Oxyva Capital', '201555115296', '', 'consulting learning', 'oxyva-eg.com', 'GoDaddy', 'oxyva', '', '', '', 1, 1, '2026-06-04 18:44:16', '2026-06-04 18:44:16'),
(33, 'م / محمود محمد', 'Ovo Way', '201025500011', '', '', 'ovo-way.com', 'GoDaddy', 'ovoway', '', '', '', 1, 1, '2026-06-04 18:46:52', '2026-06-04 18:46:52'),
(34, 'م / احمد عبد العال', 'Sedra Oman', '201005151818', '', 'cosmetics', 'sedra-om.com', 'GoDaddy', 'sedraom', '', '', '', 1, 1, '2026-06-04 18:53:18', '2026-06-04 18:53:18'),
(35, 'م / عبد الرحمن فرغلي', 'Exception CO', '201006829244', '', 'construction', 'exception-co.com', 'GoDaddy', 'exceptionco', '', '', '', 1, 1, '2026-06-04 18:56:03', '2026-06-04 18:56:03'),
(36, 'م / احمد ابراهيم', 'Elhassan P S', '201068500268', '', 'Printing Supply', 'elhassan-ps.com', 'GoDaddy', 'elhassan', '', '', '', 1, 1, '2026-06-04 19:03:55', '2026-06-04 19:03:55'),
(37, 'م / احمد ابراهيم', 'Makkah EST', '201068500268', '', 'construction', 'makkahest.com', 'GoDaddy', 'makkahest', '', '', '', 1, 1, '2026-06-04 19:05:57', '2026-06-04 19:05:57'),
(38, 'م / يوسف هشام', 'reelify', '201505588416', '', 'videos Converter', 'reelify.cc', 'dynadot', 'reelify', '', '', '', 1, 1, '2026-06-04 19:09:16', '2026-06-04 19:10:08'),
(39, 'م / احمد رؤوف', 'Nour Tiba', '201028085860', '', 'مكتب محاسبة', 'nourtiba-eg.com', 'GoDaddy', 'nourtiba', '', '', '', 1, 1, '2026-06-04 19:11:56', '2026-06-04 19:11:56'),
(40, 'م / عمرو عبد الموجود', 'AB Pro Medical', '201091166448', '', 'Medical', 'abpromedical.com', 'GoDaddy', 'abpromedical', '', '', '', 1, 1, '2026-06-04 19:15:39', '2026-06-04 19:15:39'),
(41, 'م / جمال محمد', 'Burhank', '201210400738', '', 'Contracting', 'burhank.com', 'Hostinger', 'burhank', '', '', '', 1, 1, '2026-06-04 19:18:26', '2026-06-04 19:18:26'),
(42, 'م / احمد سرور', 'Prime Gate Tech', '201227187286', '', '', 'primegatetech.com', 'GoDaddy', 'primegatetech', '', '', '', 1, 1, '2026-06-04 19:30:05', '2026-06-04 19:30:05'),
(43, 'م / اسلام اسامة', 'Almotaheda Engineering', '201012173608', '', 'Engineering', 'almotaheda-eng.com', 'GoDaddy', 'almotaheda', '', '', '', 1, 1, '2026-06-04 19:36:48', '2026-06-04 19:36:48'),
(44, 'عميد يحي المراسي', 'International CP', '201018920639', '', '', 'international-cp.com', 'GoDaddy', 'internationalcp', '', '', '', 1, 1, '2026-06-04 19:39:03', '2026-06-04 19:39:03'),
(45, 'م / تامر', 'Alkayan Transport', '201501400887', '', 'Transportation', 'alkayan-trans.com', 'GoDaddy', 'alkayantrans', '', '', '', 1, 1, '2026-06-04 19:42:26', '2026-06-04 19:42:26'),
(46, 'م / محمد فتاح', 'Fattah Foundation', '201130713582', '', 'Contracting', 'fattahfoundation.com', 'GoDaddy', 'fattahfoundation', '', '', '', 1, 1, '2026-06-04 19:45:08', '2026-06-04 19:45:08'),
(47, 'م / محمد سعيد', 'Enbridge', '201220404582', '', 'Petroleum Services', 'enbridge-eg.com', 'GoDaddy', 'enbridge', '', '', '', 1, 1, '2026-06-04 19:48:28', '2026-06-04 19:48:28'),
(48, 'م / عبد الحميد عرابي', 'Oujaj Salt', '201003738806', '', '', 'oujajsalt.com', 'GoDaddy', 'oujajsalt', '', '', '', 1, 1, '2026-06-04 19:51:27', '2026-06-04 19:51:27'),
(49, 'م / هيثم', 'White Group', '201050207906', '', 'Contracting', 'whitegroup-eng.com', 'GoDaddy', 'whitegroup-eng', '', '', '', 1, 1, '2026-06-04 19:53:49', '2026-06-04 19:53:49'),
(50, 'م / محمد عبد الله', 'Pro Creativity', '010', '', 'Contracting', 'procreativity.net', 'GoDaddy', 'procreativity', '', '', '', 1, 1, '2026-06-04 19:55:58', '2026-06-04 19:55:58'),
(51, 'م / ابو العيبد', 'Egy Fruitex', '201028240959', '', 'Fruitex', 'egy-fruitex.com', 'GoDaddy', 'egyfruitex', '', '', '', 1, 1, '2026-06-04 19:59:13', '2026-06-04 19:59:13'),
(52, 'م / محمد علي', 'Ellevate Marketing', '201150695780', NULL, 'Marketing', 'ellevatemarketing.com', 'Netlify', 'ellevatemarketing', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(53, 'م / يوسف', 'G-Tech Solution', '201210622000', NULL, 'Tech', 'g-tech-solution.com', 'Godady', 'g-tech-solution', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(54, 'م / عمرو خالد', 'Construct Code', '201012468796', NULL, 'Contracting', 'Construct-code.com', 'Godady', 'Construct-code', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(55, 'م / نبيل رضا', 'Future Green', '201113416722', NULL, 'تجارة العدد اليدوية وانظمة الحريق', 'future-green.net', 'Godady', 'future-green', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(56, 'م / محمود مجدي', 'snoby', '201018766588', NULL, 'cosmetics', 'snoby-eg.com', 'Godady', 'snoby', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(57, 'م / خالد منصور', 'Omega', '201117013024', NULL, 'supplies', 'omega-supplies.com', 'Godady', 'omega-supplies', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(58, 'م / ريم', 'myriad', '201157184292', NULL, NULL, 'myriad-co.com', 'Godady', 'myriad-co', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(59, 'م / شريف مجدي', 'Senior Constructions', '201017571005', NULL, 'Constructions', 'seniorconstructions.com', 'Godady', 'seniorconstructions', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(60, 'م / السيد هاني', 'Alamana', '201280265841', NULL, 'Transport', 'alamanatransport.com', 'Godady', 'alamanatransport', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(61, 'م / فهمي جاد', 'Alnasem', '201100691874', NULL, NULL, 'alnasem-eg.com', 'Godady', 'alnasem-eg', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(62, 'د / مصطفي', 'Medx Hub', '201003939499', NULL, 'Medical', 'medx-hub.com', 'Godady', 'medx-hub', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(63, 'م / تامر خليل', 'Smart Partner', '201225770713', NULL, 'agency', 'smartpartner.agency', 'Godady', 'smartpartner', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(64, 'م / مروان هشام', 'Wijha Express', '201143594429', NULL, 'Express', 'wijha.express', 'Godady', 'wijha', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(65, 'م / ت', 'Transmission', '249123885888', NULL, 'Digital Marketing', 'transmission-dma.com', 'Godady', 'transmission', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(66, 'م / هدوي علي', 'plus-adv', '201147080280', NULL, 'Digital Marketing', 'plus-adv.com', 'Godady', 'plus-adv', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(67, 'م / كريم', 'Alfa Petroleum', '201124252602', NULL, 'Petroleum', 'alfa-petroleum.com', 'Godady', 'alfa-petroleum', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(68, 'م / نيرة الليثي', 'Eldewanya', '201093577377', NULL, 'تصدير', 'eldewanya.com', 'Godady', 'eldewanya', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(69, 'م / عبد اللطيف محمد', 'infinity Logistic', '201080146149', NULL, 'Logistic', 'infinity-logistic.net', 'Godady', 'infinity-logistic', NULL, NULL, NULL, 1, 1, '2026-06-04 20:15:15', '2026-06-04 20:15:15'),
(70, 'م / تامر', 'Alkayan Logistics', '201040405470', '', '', 'alkayanlogistics.com', 'GoDaddy', 'alkayanlogistics', '', '', '', 1, 1, '2026-06-04 20:16:28', '2026-06-04 20:16:28'),
(71, 'م / محمد عبد الله', 'Madar MEP', '201060565785', '', 'MEP', 'MadarMEP.com', 'GoDaddy', 'madarmep', '', '', '', 1, 1, '2026-06-04 20:17:20', '2026-06-04 20:17:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
